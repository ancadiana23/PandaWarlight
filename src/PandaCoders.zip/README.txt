Belmega Diana-Elena, 322CA
Bojinovici Andrei-Lucian, 322CA
Patrascanu Andra-Maria, 322CA
Vicol Anca-Diana, 322CA


Strategia noastra trateaza doua cazuri: 

1)N-avem inamici vizibili:
Determinam superRegiunea cu cel mai mare raport bonus/efort(nr. de 
regiuni de cucerit) si o prioritizam.
Acolo vom pune armate pentru a o cuceri. Se repeta pana cand nu mai avem armate.
Nota: superRegiunile cu aceeasi prioritate, dar care necesita mai putin efort
(mai putine regiuni de cucerit) sunt prioritare.
In timpul deploy-ului, cream o lista cu atacurile viitoare (pentru a nu mai parcurge
din nou aceleasi for-uri).

2) Daca avem inamici vizibili:
Ne aparam regiunile vecine cu inamicii, in functie de cate armate au momentan (fara a 
prezice ca vor fi mai multe). Daca toate sunt aparate, se continua cu strategia de la punctul
 1). Daca exista o regiune care nu poate fi aparata suficient, o determinam pe cea mai vulnerabila si punem restul armatelor (daca mai sunt) acolo (motivul: in caz ca inamicul ne va cuceri regiunea respectiva, va avea mai putine armate cu care sa atace regiunile vecine).

In functia care face transferurile si atacurile, mai intai transferam
toate armate de pe regiunile interioare (regiuni inconjurate numai de aliati) in
cea mai apropiata regiune care are vecini inamici sau neutrii. 
Apoi atacam din teritoriile de pe margine (care nu au numai aliati in jur) teritoriile, indiferent daca sunt inamici sau neutrii, care fac parte din cele mai pretioase superRegiuni pana cand nu mai avem cu ce sa atacam sau ramanem cu un numar de armate necesare apararii.

Partea random de la deploy este o modificare a codului original de pe site.
Scheletul de cod este de asemenea de pe site-ul pub.theaigames.com, la care noi am adaugat ce ne trebuie.
